<?php 
class Kendaraan { 
    public $merk; 

    public function __construct($merk) { 
        $this->merk = $merk; 
    } 

    public function tampilkanMerk() { 
        return "Merk: " . $this->merk; 
    } 
} 

class Mobil extends Kendaraan { 
    public function infoMobil() { 
        return "Ini adalah mobil " . $this->merk; 
    } 

    public function jumlahPintu() {
        return "Jumlah pintu: 4";
    }
} 

$mobil= new Mobil("Honda"); 
echo $mobil1->tampilkanMerk()."<br>"; 
echo $mobil1->infoMobil()."<br>"; 
echo $mobil1->jumlahPintu();
?>