<?php

interface TransportasiOnline {
    public function berhasil();
    public function Namapelanggan();
    public function jenislayanan();
    public function pesan();
    public function batalkan();
    public function cekStatus();   
}

class GoRide implements TransportasiOnline {
    public function berhasil() {
        echo "Pesanan Maulanaberhasil  dibuat";
    }
    public function Namapelanggan() {
        echo "Nama Pelanggan: Maulana";
    }
    public function jenislayanan() {
        echo "Jenis Layanan: GoRide";
    }
    public function pesan() {
        echo "Pesanan GoRide berhasil dibuat";
    }
    public function batalkan() {
        echo "Pesanan GoRide dibatalkan";
    }
    public function cekStatus() {
        echo "Status pesanan GoRide: Sedang dalam perjalanan";
    }
}

class GoCar implements TransportasiOnline {
    public function berhasil() {
        echo "Pesanan Manda Putri berhasil dibuat";
    }
    public function Namapelanggan() {
        echo "Nama Pelanggan: Manda Putri";
    }
    public function jenislayanan() {
        echo "Jenis Layanan: GoCar";
    }
    public function pesan() {
        echo "Pesanan GoCar berhasil dibuat";
    }
    public function batalkan() {
        echo "Pesanan GoCar dibatalkan";
    }
    public function cekStatus() {
        echo "Status pesanan GoCar: Sedang dalam perjalanan";
    }
}
class GoFood implements TransportasiOnline {
    public function berhasil() {
        echo "Pesanan Pejuang Hebat berhasil dibuat";
    }
    public function Namapelanggan() {
        echo "Nama Pelanggan: Pejuang Hebat";
    }
    public function jenislayanan() {
        echo "Jenis Layanan: GoFood";
    }
    public function pesan() {
        echo "Pesanan GoFood berhasil dibuat";
    }
    public function batalkan() {
        echo "Pesanan GoFood dibatalkan";
    }
    public function cekStatus() {
        echo "Status pesanan GoFood: Sedang dalam perjalanan";
    }
}
class GoSend implements TransportasiOnline {
    public function berhasil() {
        echo "Pesanan Bapak Julian berhasil dibuat";
    }
    public function Namapelanggan() {
        echo "Nama Pelanggan: Bapak Julian";
    }
    public function jenislayanan() {
        echo "Jenis Layanan: GoSend";
    }
    public function pesan() {
        echo "Pesanan GoSend berhasil dibuat";
    }
    public function batalkan() {
        echo "Pesanan GoSend dibatalkan";
    }
    public function cekStatus() {
        echo "Status pesanan GoSend: Sedang dalam perjalanan";
    }
}

?>
