siswa = {
    "nama": "Demian",
    "umur": 17,
    "jurusan": "EKONOMI & BISNIS"
}

siswa["alamat"] = "JAKARTA"
siswa["umur"] = 18

print(siswa)
