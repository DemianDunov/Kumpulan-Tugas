siswa = {
    "nama": "Demian",
    "umur": 18,
    "jurusan": "EKONOMI & BISNIS"
}

print("Nama:", siswa["nama"])
print("Umur:", siswa["umur"])
print("Jurusan:", siswa["jurusan"])
