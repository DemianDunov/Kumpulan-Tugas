produk = {
    "produk1": {"nama": "Buku Tulis", "harga": 2500, "stok": 10},
    "produk2": {"nama": "Pulpen ", "harga": 250, "stok": 20},
    "produk3": {"nama": "Penghapus ", "harga": 150, "stok": 10}
}

# tampil semua data
for key, value in produk.items():
    print(key, ":", value)

# hitung total nilai stok
total = 0
for item in produk.values():
    total += item["harga"] * item["stok"]

print("Total nilai stok:", Yen)