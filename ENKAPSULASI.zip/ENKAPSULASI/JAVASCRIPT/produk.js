class Produk {
  #nama;
  #harga;
  setNama(n) {
    this.#nama = n;
  }
  getNama() {
    return this.#nama;
  }
  setHarga(h) {
    if (h >= 0) this.#harga = h;
  }
  getHarga() {
    return this.#harga;
  }
}
let produk = new Produk();
produk.setNama("Laptop");
produk.setHarga(5000000);
console.log("Produk:", produk.getNama(), produk.getHarga());