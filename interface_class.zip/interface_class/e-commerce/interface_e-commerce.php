<?php

interface BelanjaOnline {
    public function beliProduk($namaProduk);
    public function checkout();
    public function batalkanpesanan();
    public function lacakpengiriman();
}

class Shopee implements BelanjaOnline {
    public function beliProduk($namaProduk) {
        echo "Produk $namaProduk ditambahkan ke keranjang Shopee";
    }
    public function beliProduk2($namaProduk) {
        echo "Produk $namaProduk ditambahkan ke keranjang Shopee";
    }
    public function checkout() {
        echo "Checkout Shopee berhasil";
    }
    public function batalkanpesanan() {
        echo "Pesanan di Shopee dibatalkan";
    }
    public function lacakpengiriman() {
        echo "Lacak pengiriman di Shopee";
    }
}

class Tokopedia implements BelanjaOnline {
    public function beliProduk($namaProduk) {
        echo "Produk $namaProduk ditambahkan ke keranjang Tokopedia";
    }
    public function beliProduk2($namaProduk) {
        echo "Produk $namaProduk ditambahkan ke keranjang Tokopedia";
    }
    public function checkout() {
        echo "Checkout Tokopedia berhasil";
    }
    public function batalkanpesanan() {
        echo "Pesanan di Tokopedia dibatalkan";
    }
    public function lacakpengiriman() {
        echo "Lacak pengiriman di Tokopedia";
    }
}
class Lazada implements BelanjaOnline {
    public function beliProduk($namaProduk) {
        echo "Produk $namaProduk ditambahkan ke keranjang Lazada";
    }
    public function beliProduk2($namaProduk) {
        echo "Produk $namaProduk ditambahkan ke keranjang Lazada";
    }
    public function checkout() {
        echo "Checkout Lazada berhasil";
    }
    public function batalkanpesanan() {
        echo "Pesanan di Lazada dibatalkan";
    }
    public function lacakpengiriman() {
        echo "Lacak pengiriman di Lazada";
    }
}
class Blibli implements BelanjaOnline {
    public function beliProduk($namaProduk) {
        echo "Produk $namaProduk ditambahkan ke keranjang Blibli";
    }
    public function beliProduk2($namaProduk) {
        echo "Produk $namaProduk ditambahkan ke keranjang Blibli";
    }
    public function checkout() {
        echo "Checkout Blibli berhasil";
    }
    public function batalkanpesanan() {
        echo "Pesanan di Blibli dibatalkan";
    }
    public function lacakpengiriman() {
        echo "Lacak pengiriman di Blibli";
    }
}

?>
