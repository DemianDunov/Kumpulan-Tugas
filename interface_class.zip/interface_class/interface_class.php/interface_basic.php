<?php
interface ProdukEkspor { 
    public function cekHargaUsd(); 
    public function cekNegara(); 
} 
 
class Televisi implements ProdukEkspor { 
    public function cekHargaUsd(){ 
        return 185; 
    } 
    public function cekNegara(){ 
        return ["Singapura", "Malaysia","Thailand"]; 
    }
} 
$produk01 = new Televisi(); 
echo $produk01->cekHargaUsd(); 
echo "<br>"; 
echo implode(", ",$produk01->cekNegara());
echo "<br>";


interface ProdukEkspor2 { 
    public function cekHargaUsd2(); 
    public function cekNegara(); 
}  
interface ProdukMakanan { 
    public function cekExpired(); 
} 
interface ProdukMakananBeku { 
    public function cekSuhuMin(); 
}
class Nugget implements ProdukEkspor2, ProdukMakanan, ProdukMakananBeku { 
    public function cekHargaUsd2(){ 
        return 7.5; 
    } 
    public function cekNegara(){ 
        return ["Singapura", "Malaysia","Thailand"]; 
    } 
    public function cekExpired(){ 
        return "April 2019"; 
    } 
    public function cekSuhuMin(){
        return -14;
    } 
} 
 
$produk01 = new Nugget(); 
echo $produk01->cekHargaUsd2(); 
echo "<br>"; 
echo implode(", ",$produk01->cekNegara()); 
echo "<br>"; 
echo $produk01->cekExpired(); 
echo "<br>"; 
echo $produk01->cekSuhuMin(); 
?>