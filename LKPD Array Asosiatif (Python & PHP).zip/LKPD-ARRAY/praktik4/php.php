<?php
$data_siswa = [
    "s1" => ["nama" => "Dina", "umur" => 23],
    "s2" => ["nama" => "Fajar", "umur" => 27],
    "s3" => ["nama" => "Lina", "umur" => 35]
];

// tampilkan semua siswa
foreach ($data_siswa as $key => $value) {
    echo $key . " {'nama': '" . $value["nama"] . "', 'umur': " . $value["umur"] . "}<br>";
}

echo "<br>";

// tampilkan salah satu data berdasarkan key
$siswa = $data_siswa["s1"];
echo "Data s1: {'nama': '" . $siswa["nama"] . "', 'umur': " . $siswa["umur"] . "}";
?>