// Abstract Class
class Komputer {

    constructor() {
        if (this.constructor === Komputer) {
            throw new Error("Class Komputer tidak bisa dibuat langsung!");
        }
    }

    lihat_merk() {
        throw new Error("Method harus diisi!");
    }

    lihat_processor() {
        throw new Error("Method harus diisi!");
    }

    lihat_harddisk() {
        throw new Error("Method harus diisi!");
    }
}

// Laptop
class Laptop extends Komputer {

    lihat_merk() {
        return "Asus";
    }

    lihat_processor() {
        return "Intel Core i7";
    }

    lihat_harddisk() {
        return "SSD 512GB";
    }
}

// Notebook
class Notebook extends Komputer {

    lihat_merk() {
        return "Acer";
    }

    lihat_processor() {
        return "Intel Celeron";
    }

    lihat_harddisk() {
        return "SSD 256GB";
    }
}

// Tablet
class Tablet extends Komputer {

    lihat_merk() {
        return "Samsung";
    }

    lihat_processor() {
        return "Snapdragon 8 Gen 2";
    }

    lihat_harddisk() {
        return "128GB";
    }
}


// OUTPUT

try {

    const laptop = new Laptop();

    console.log("=== Laptop ===");
    console.log("Merk :", laptop.lihat_merk());
    console.log("Processor :", laptop.lihat_processor());
    console.log("Harddisk :", laptop.lihat_harddisk());

    console.log("");

    const notebook = new Notebook();

    console.log("=== Notebook ===");
    console.log("Merk :", notebook.lihat_merk());
    console.log("Processor :", notebook.lihat_processor());
    console.log("Harddisk :", notebook.lihat_harddisk());

    console.log("");

    const tablet = new Tablet();

    console.log("=== Tablet ===");
    console.log("Merk :", tablet.lihat_merk());
    console.log("Processor :", tablet.lihat_processor());
    console.log("Harddisk :", tablet.lihat_harddisk());

} catch (error) {

    console.log(error.message);

}