<?php

// Abstract Class
abstract class Komputer {

    abstract public function lihat_merk();
    abstract public function lihat_processor();
    abstract public function lihat_harddisk();
}

// Class Laptop
class Laptop extends Komputer {

    public function lihat_merk() {
        return "Asus";
    }

    public function lihat_processor() {
        return "Intel Core i7";
    }

    public function lihat_harddisk() {
        return "SSD 512GB";
    }
}

// Class Notebook
class Notebook extends Komputer {

    public function lihat_merk() {
        return "Acer";
    }

    public function lihat_processor() {
        return "Intel Celeron";
    }

    public function lihat_harddisk() {
        return "SSD 256GB";
    }
}

// Class Tablet
class Tablet extends Komputer {

    public function lihat_merk() {
        return "Samsung";
    }

    public function lihat_processor() {
        return "Snapdragon 8 Gen 2";
    }

    public function lihat_harddisk() {
        return "128GB";
    }
}


// OUTPUT

$laptop = new Laptop();
echo "<h3>Laptop</h3>";
echo $laptop->lihat_merk() . "<br>";
echo $laptop->lihat_processor() . "<br>";
echo $laptop->lihat_harddisk() . "<br><br>";

$notebook = new Notebook();
echo "<h3>Notebook</h3>";
echo $notebook->lihat_merk() . "<br>";
echo $notebook->lihat_processor() . "<br>";
echo $notebook->lihat_harddisk() . "<br><br>";

$tablet = new Tablet();
echo "<h3>Tablet</h3>";
echo $tablet->lihat_merk() . "<br>";
echo $tablet->lihat_processor() . "<br>";
echo $tablet->lihat_harddisk() . "<br>";

?>