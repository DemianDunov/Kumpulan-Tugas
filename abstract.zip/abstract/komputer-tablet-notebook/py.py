from abc import ABC, abstractmethod

# Abstract Class
class Komputer(ABC):

    @abstractmethod
    def lihat_merk(self):
        pass

    @abstractmethod
    def lihat_processor(self):
        pass

    @abstractmethod
    def lihat_harddisk(self):
        pass


# Laptop
class Laptop(Komputer):

    def lihat_merk(self):
        return "Asus"

    def lihat_processor(self):
        return "Intel Core i7"

    def lihat_harddisk(self):
        return "SSD 512GB"


# Notebook
class Notebook(Komputer):

    def lihat_merk(self):
        return "Acer"

    def lihat_processor(self):
        return "Intel Celeron"

    def lihat_harddisk(self):
        return "SSD 256GB"


# Tablet
class Tablet(Komputer):

    def lihat_merk(self):
        return "Samsung"

    def lihat_processor(self):
        return "Snapdragon 8 Gen 2"

    def lihat_harddisk(self):
        return "128GB"


# OUTPUT

laptop = Laptop()
print("Laptop")
print(laptop.lihat_merk())
print(laptop.lihat_processor())
print(laptop.lihat_harddisk())

print()

notebook = Notebook()
print("Notebook")
print(notebook.lihat_merk())
print(notebook.lihat_processor())
print(notebook.lihat_harddisk())

print()

tablet = Tablet()
print("Tablet")
print(tablet.lihat_merk())
print(tablet.lihat_processor())
print(tablet.lihat_harddisk())