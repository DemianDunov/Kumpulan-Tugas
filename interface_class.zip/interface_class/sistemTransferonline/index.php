<?php
require 'Interface_sistemtransferonline.php';
$ride = new GoRide();
$car = new GoCar();
$food = new GoFood();
$send = new GoSend();

$ride->berhasil();
echo "<br>";
$ride->Namapelanggan();
echo "<br>";
$ride->jenislayanan();
echo "<br>";
$ride->pesan();
echo "<br>";
$ride->batalkan();
echo "<br>";
$ride->cekStatus();
echo "<hr>";

$car->berhasil();
echo "<br>";
$car->Namapelanggan();
echo "<br>";
$car->jenislayanan();
echo "<br>";
$car->pesan();
echo "<br>";
$car->batalkan();
echo "<br>";
$car->cekStatus(); 
echo "<hr>";

$food->berhasil();
echo "<br>";
$food->Namapelanggan();
echo "<br>";
$food->jenislayanan();
echo "<br>";
$food->pesan();
echo "<br>";
$food->batalkan();
echo "<br>";
$food->cekStatus();
echo "<hr>";

$send->berhasil();
echo "<br>";
$send->Namapelanggan();
echo "<br>";
$send->jenislayanan();
echo "<br>";
$send->pesan();
echo "<br>";
$send->batalkan();
echo "<br>";
$send->cekStatus();
echo "<hr>";
?>