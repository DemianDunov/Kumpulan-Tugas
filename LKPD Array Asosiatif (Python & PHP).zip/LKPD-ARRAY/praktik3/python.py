siswa = {
    "nama": "Demian",
    "umur": 18,
    "jurusan": "EKONOMI & BISNIS",
    "alamat": "JAKARTA"
}

for key, value in siswa.items():
    print(key, ":", value)
