<?php
$siswa = [
    "nama" => "Demian",
    "umur" => 18,
    "jurusan" => "EKONOMI & BISNIS",
    "alamat" => "JAKARTA"
];

foreach ($siswa as $key => $value) {
    echo $key . " : " . $value . "<br>";
}
?>