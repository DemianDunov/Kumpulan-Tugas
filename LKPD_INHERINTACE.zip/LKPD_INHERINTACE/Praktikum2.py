class Kendaraan:
    def __init__(self, merk):
        self.merk = merk

    def tampilkan_merk(self):
        return f"Merk: {self.merk}"

class Mobil(Kendaraan):
    def info_mobil(self):
        return f"Ini adalah mobil {self.merk}"
    
    def warna(self):
        return "Warna: Hitam"

mobil1 = Mobil("Suzuki")
print(mobil1.tampilkan_merk())
print(mobil1.info_mobil())
print(mobil1.warna())