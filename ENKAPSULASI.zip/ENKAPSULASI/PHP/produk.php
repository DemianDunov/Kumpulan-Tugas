<?php
class Produk {
    private $nama;
    private $harga;
    function setNama($nama){ $this->nama = $nama; }
    function getNama(){ return $this->nama; }
    function setHarga($harga){ if($harga >= 0) $this->harga = $harga; }
    function getHarga(){ return $this->harga; }
}
?>