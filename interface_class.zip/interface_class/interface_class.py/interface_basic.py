from abc import ABC, abstractmethod

class ProdukEkspor(ABC):
    def CekHargaUsd(self):
        pass

    def CekNegara(self):
        pass

class Televisi(ProdukEkspor):
    def CekHargaUsd(self):
        return 185

    def CekNegara(self):
        return("Singapura", "Malaysia", "Thailand")
    
produk1 = Televisi()
print("Nomor Televisi:", produk1.CekHargaUsd())
print("," .join(produk1.CekNegara()))

class ProdukEkspor2(ABC):
    def CekHargaUsd2(self):
        pass
    def CekNegara(self):
        pass
class Makanan(ABC):
    def CekExpaired(self):
        pass
class ProdukMakananBeku(ABC):
    def CekSuhu(self):
        pass
class Nugget(ProdukEkspor2, Makanan, ProdukMakananBeku):
    def CekHargaUsd2(self):
        return 10
    def CekNegara(self):
        return ("Indonesia", "Malaysia", "Singapura")
    def CekExpaired(self):
        return "2024-12-31"
    def CekSuhu(self):
        return "-18 derajat Celsius"
    
produk2 = Nugget()
print("Barang:", produk2.CekHargaUsd2())
print("Negara Tujuan:", ", ".join(produk2.CekNegara()))
print("Tanggal Expired:", produk2.CekExpaired())
print("Suhu Penyimpanan:", produk2.CekSuhu())