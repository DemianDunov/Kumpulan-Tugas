class Mobil:
    def __init__(self, warna, kecepatan):
        self.__warna = warna
        self.__kecepatan = kecepatan

    def set_warna(self, warna):
        self.__warna = warna

    def get_warna(self):
        return self.__warna

    def set_kecepatan(self, k):
        if k >= 0:
            self.__kecepatan = k

    def get_kecepatan(self):
        return self.__kecepatan
mobil = Mobil("Merah", 100)
print("Mobil:", mobil.get_warna(), mobil.get_kecepatan())

mobil.set_warna("Hitam")
mobil.set_kecepatan(150)
print("Mobil update:", mobil.get_warna(), mobil.get_kecepatan())