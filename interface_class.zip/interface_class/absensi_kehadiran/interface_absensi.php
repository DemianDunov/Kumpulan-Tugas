<?php

interface Absensi {
    public function hadir($nama);
    public function izin($nama);
}

class Siswa implements Absensi {

    public function hadir($nama) {
        echo "$nama tercatat hadir";
    }
    public function izin($nama) {
        echo "$nama tercatat izin";
    }
    public function sakit($nama) {
        echo "$nama tercatat sakit";
    }
    public function alpa($nama) {
        echo "$nama tercatat alpa";
    }
}
class Guru implements Absensi {

    public function hadir($nama) {
        echo "Guru $nama tercatat hadir";
    }
    public function izin($nama) {
        echo "Guru $nama tercatat izin";
    }
    public function sakit($nama) {
        echo "Guru $nama tercatat sakit";
    }
    public function alpa($nama) {
        echo "Guru $nama tercatat alpa";
    }
}
class Karyawan implements Absensi {

    public function hadir($nama) {
        echo "Karyawan $nama tercatat hadir";
    }
    public function izin($nama) {
        echo "Karyawan $nama tercatat izin";
    }
    public function sakit($nama) {
        echo "Karyawan $nama tercatat sakit";
    }
    public function alpa($nama) {
        echo "Karyawan $nama tercatat alpa";
    }
}

?>
