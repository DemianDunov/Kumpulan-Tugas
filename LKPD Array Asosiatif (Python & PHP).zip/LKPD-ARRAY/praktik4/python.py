data_siswa = {
    "s1": {"nama": "Dina", "umur": 23},
    "s2": {"nama": "Fajar", "umur": 27},
    "s3": {"nama": "Lina", "umur": 35}
}

for key, value in data_siswa.items():
    print(key, value)

print("Data s1:", data_siswa["s1"])
