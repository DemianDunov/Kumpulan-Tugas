<?php
require 'interface_elektronik.php';
$lampu = new Lampu();
echo $lampu->hidupkan() . "<br>";
echo $lampu->matikan() . "<br>";
$tv = new TV();
echo $tv->hidupkan() . "<br>";
echo $tv->matikan() . "<br>";
?>