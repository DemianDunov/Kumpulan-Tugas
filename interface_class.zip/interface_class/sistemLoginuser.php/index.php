<?php
require 'Interface_sistemloginuser.php';
$admin = new Admin();
$admin->masuk("Admin", "1123");
echo "<br>";
$admin->logout();
echo "<br>";
$admin->gantiPassword("Admin", "1123", "89922");
echo "<hr>";

$guru = new Guru();
$guru->masuk("Pak Tatang", "12456");
echo "<br>";
$guru->logout();
echo "<br>";
$guru->gantiPassword("Pak Tatang", "12456", "72389");
echo "<hr>";

$siswa = new Siswa();
$siswa->masuk("Jamal", "78379");
echo "<br>";
$siswa->logout();
echo "<br>";
$siswa->gantiPassword("Jamal", "78379", "01251");
echo "<hr>";
?>