class Sepeda:
    def __init__(self, warna, kecepatan):
        self.__warna = warna
        self.__kecepatan = kecepatan

    def set_warna(self, warna):
        self.__warna = warna

    def get_warna(self):
        return self.__warna

    def set_kecepatan(self, k):
        if k >= 0:
            self.__kecepatan = k

    def get_kecepatan(self):
        return self.__kecepatan
sepeda = Sepeda("Biru", 30)
print("Sepeda:", sepeda.get_warna(), sepeda.get_kecepatan())

sepeda.set_kecepatan(40)
print("Sepeda update:", sepeda.get_warna(), sepeda.get_kecepatan())