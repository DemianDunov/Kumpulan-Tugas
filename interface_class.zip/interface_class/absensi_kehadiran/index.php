<?php
require 'interface_absensi.php';
$siswa = new Siswa();
$guru = new Guru();
$karyawan = new Karyawan();

$siswa->hadir("Andi");
echo "<br>";
$siswa->izin("Yudi");
echo "<br>";
$siswa->sakit("Mila");
echo "<br>";
$siswa->alpa("Wiliam");
echo "<hr>";
$guru->hadir("Pak Budi");
echo "<br>";
$guru->izin("Pak Dodo");
echo "<br>";
$guru->sakit("Bu Indah");
echo "<br>";
$guru->alpa("Bu Yuki");
echo "<hr>";
$karyawan->hadir("Pak Mikael");
echo "<br>";
$karyawan->izin("Bu Naya");
echo "<br>";
$karyawan->sakit("Pak Andre");
echo "<br>";
$karyawan->alpa("Bu Luna");
echo "<br>";
?>