# 1
class Buku:
    def __init__(self, judul, pengarang, harga):
        self.judul = judul
        self.pengarang = pengarang
        self.harga = harga

    def tampil_info(self):
        print(self.judul, self.pengarang, self.harga)

class BukuTeks(Buku):
    def __init__(self, judul, pengarang, harga, isbn):
        super().__init__(judul, pengarang, harga)
        self.isbn = isbn

    def tampil_info(self):
        print(self.judul, self.pengarang, self.harga, self.isbn)

BukuTeks("Math","Asep",10000,"123").tampil_info()

# 2
class Sepeda:
    def __init__(self, merek, warna, harga):
        self.merek = merek
        self.warna = warna
        self.harga = harga
    def berjalan(self):
        print("Sepeda berjalan")

class SepedaListrik(Sepeda):
    def __init__(self, merek, warna, harga, baterai):
        super().__init__(merek, warna, harga)
        self.baterai = baterai
    def isi_ulang(self):
        print("Mengisi ulang baterai")

s = SepedaListrik("Selis","Hitam",5000000,100)
s.berjalan()
s.isi_ulang()

# 3
class Mobil:
    def __init__(self, merek, warna, harga, tahun):
        self.merek = merek
        self.warna = warna
        self.harga = harga
        self.tahun = tahun
    def berjalan(self):
        print("Mobil berjalan")

class MobilListrik(Mobil):
    def __init__(self, merek, warna, harga, tahun, baterai):
        super().__init__(merek, warna, harga, tahun)
        self.baterai = baterai
    def isi_ulang(self):
        print("Mengisi ulang baterai")

m = MobilListrik("Tesla","Putih",1000000000,2024,100)
m.berjalan()
m.isi_ulang()

# 4
class BangunDatar:
    def __init__(self, warna):
        self.warna = warna
    def hitung_luas(self):
        print("Menghitung luas")

class PersegiPanjang(BangunDatar):
    def __init__(self, warna, p, l):
        super().__init__(warna)
        self.p = p
        self.l = l
    def hitung_luas(self):
        print(self.p * self.l)

PersegiPanjang("Merah",10,5).hitung_luas()

# 5
class Kendaraan:
    def __init__(self, merek, tahun):
        self.merek = merek
        self.tahun = tahun
    def berjalan(self):
        print("Kendaraan bergerak")

class Motor(Kendaraan):
    def __init__(self, merek, tahun, bbm):
        super().__init__(merek, tahun)
        self.bbm = bbm
    def nyalakan_mesin(self):
        print("Mesin mobil dinyalakan")

class Sepeda2(Kendaraan):
    def __init__(self, merek, tahun, jenis):
        super().__init__(merek, tahun)
        self.jenis = jenis
    def gowes(self):
        print("Sepeda sedang digowes")

Motor("Honda",2020,"Bensin").nyalakan_mesin()
Sepeda2("Polygon",2022,"Gunung").gowes()

# 6
class Hewan:
    def suara(self):
        print("Hewan bersuara")

class Kucing(Hewan):
    def suara(self):
        print("Meow!")

class Anjing(Hewan):
    def suara(self):
        print("Woof!")

class Kelinci(Hewan):
    def suara(self):
        print("Squeak!")

Kucing().suara()
Anjing().suara()
Kelinci().suara()

# 7
import math
class Lingkaran(BangunDatar):
    def __init__(self, r):
        self.r = r
    def hitung_luas(self):
        print(math.pi * self.r * self.r)

class Segitiga(BangunDatar):
    def __init__(self, a, t):
        self.a = a
        self.t = t
    def hitung_luas(self):
        print(0.5 * self.a * self.t)

Lingkaran(7).hitung_luas()
Segitiga(10,5).hitung_luas()

# 8
class Barang:
    def __init__(self, nama, harga):
        self.nama = nama
        self.harga = harga
    def tampil_info(self):
        print(self.nama, self.harga)

class Elektronik(Barang):
    def __init__(self, nama, harga, garansi):
        super().__init__(nama, harga)
        self.garansi = garansi
    def tampil_info(self):
        print(self.nama, self.harga, self.garansi)

class Pakaian(Barang):
    def __init__(self, nama, harga, ukuran):
        super().__init__(nama, harga)
        self.ukuran = ukuran
    def tampil_info(self):
        print(self.nama, self.harga, self.ukuran)

class Makanan(Barang):
    def __init__(self, nama, harga, exp):
        super().__init__(nama, harga)
        self.exp = exp
    def tampil_info(self):
        print(self.nama, self.harga, self.exp)

Elektronik("HP",3000000,"1 tahun").tampil_info()
Pakaian("Kaos",100000,"L").tampil_info()
Makanan("Roti",20000,"2026").tampil_info()