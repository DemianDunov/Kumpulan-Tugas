// 1. Buku & BukuTeks
class Buku {
    constructor(judul, pengarang, harga) {
        this.judul = judul;
        this.pengarang = pengarang;
        this.harga = harga;
    }

    tampilInfo() {
        console.log(this.judul, this.pengarang, this.harga);
    }
}

class BukuTeks extends Buku {
    constructor(judul, pengarang, harga, isbn) {
        super(judul, pengarang, harga);
        this.isbn = isbn;
    }

    tampilInfo() {
        console.log(this.judul, this.pengarang, this.harga, "ISBN:", this.isbn);
    }
}

new BukuTeks("Matematika","Asep",10000,"123").tampilInfo();


// 2. Sepeda & SepedaListrik
class Sepeda {
    constructor(merek, warna, harga) {
        this.merek = merek;
        this.warna = warna;
        this.harga = harga;
    }

    berjalan() {
        console.log("Sepeda berjalan");
    }
}

class SepedaListrik extends Sepeda {
    constructor(merek, warna, harga, baterai) {
        super(merek, warna, harga);
        this.baterai = baterai;
    }

    isiUlang() {
        console.log("Mengisi ulang baterai");
    }
}

let s = new SepedaListrik("Selis","Hitam",5000000,100);
s.berjalan();
s.isiUlang();


// 3. Mobil & MobilListrik
class Mobil {
    constructor(merek, warna, harga, tahun) {
        this.merek = merek;
        this.warna = warna;
        this.harga = harga;
        this.tahun = tahun;
    }

    berjalan() {
        console.log("Mobil berjalan");
    }
}

class MobilListrik extends Mobil {
    constructor(merek, warna, harga, tahun, baterai) {
        super(merek, warna, harga, tahun);
        this.baterai = baterai;
    }

    isiUlang() {
        console.log("Mengisi ulang baterai");
    }
}

let m = new MobilListrik("Tesla","Putih",1000000000,2024,100);
m.berjalan();
m.isiUlang();


// 4. BangunDatar & PersegiPanjang
class BangunDatar {
    constructor(warna) {
        this.warna = warna;
    }

    hitungLuas() {
        console.log("Menghitung luas bangun datar");
    }
}

class PersegiPanjang extends BangunDatar {
    constructor(warna, p, l) {
        super(warna);
        this.p = p;
        this.l = l;
    }

    hitungLuas() {
        console.log("Luas:", this.p * this.l);
    }
}

new PersegiPanjang("Merah",10,5).hitungLuas();


// 5. Kendaraan, Motor, Sepeda
class Kendaraan {
    constructor(merek, tahun) {
        this.merek = merek;
        this.tahun = tahun;
    }

    berjalan() {
        console.log("Kendaraan bergerak");
    }
}

class Motor extends Kendaraan {
    constructor(merek, tahun, bbm) {
        super(merek, tahun);
        this.bbm = bbm;
    }

    nyalakanMesin() {
        console.log("Mesin mobil dinyalakan");
    }
}

class Sepeda2 extends Kendaraan {
    constructor(merek, tahun, jenis) {
        super(merek, tahun);
        this.jenis = jenis;
    }

    gowes() {
        console.log("Sepeda sedang digowes");
    }
}

new Motor("Honda",2020,"Bensin").nyalakanMesin();
new Sepeda2("Polygon",2022,"Gunung").gowes();


// 6. Hewan
class Hewan {
    suara() {
        console.log("Hewan bersuara");
    }
}

class Kucing extends Hewan {
    suara() {
        console.log("Meow!");
    }
}

class Anjing extends Hewan {
    suara() {
        console.log("Woof!");
    }
}

class Kelinci extends Hewan {
    suara() {
        console.log("Squeak!");
    }
}

new Kucing().suara();
new Anjing().suara();
new Kelinci().suara();


// 7. Lingkaran & Segitiga
class Lingkaran {
    constructor(r) {
        this.r = r;
    }

    hitungLuas() {
        console.log("Luas Lingkaran:", Math.PI * this.r * this.r);
    }
}

class Segitiga {
    constructor(a, t) {
        this.a = a;
        this.t = t;
    }

    hitungLuas() {
        console.log("Luas Segitiga:", 0.5 * this.a * this.t);
    }
}

new Lingkaran(7).hitungLuas();
new Segitiga(10,5).hitungLuas();


// 8. Barang
class Barang {
    constructor(nama, harga) {
        this.nama = nama;
        this.harga = harga;
    }

    tampilInfo() {
        console.log(this.nama, this.harga);
    }
}

class Elektronik extends Barang {
    constructor(nama, harga, garansi) {
        super(nama, harga);
        this.garansi = garansi;
    }

    tampilInfo() {
        console.log(this.nama, this.harga, "Garansi:", this.garansi);
    }
}

class Pakaian extends Barang {
    constructor(nama, harga, ukuran) {
        super(nama, harga);
        this.ukuran = ukuran;
    }

    tampilInfo() {
        console.log(this.nama, this.harga, "Ukuran:", this.ukuran);
    }
}

class Makanan extends Barang {
    constructor(nama, harga, exp) {
        super(nama, harga);
        this.exp = exp;
    }

    tampilInfo() {
        console.log(this.nama, this.harga, "Exp:", this.exp);
    }
}

new Elektronik("HP",3000000,"1 tahun").tampilInfo();
new Pakaian("Kaos",100000,"L").tampilInfo();
new Makanan("Roti",20000,"2026").tampilInfo();