<?php
$siswa = [
    "nama" => "Demian",
    "umur" => 17,
    "jurusan" => "EKONOMI & BISNIS"
];

// tambah alamat
$siswa["alamat"] = "JAKARTA";

// ubah umur
$siswa["umur"] = 18;

// tampilkan hasil
echo "Nama: " . $siswa["nama"] . "<br>";
echo "Umur: " . $siswa["umur"] . "<br>";
echo "Jurusan: " . $siswa["jurusan"] . "<br>";
echo "Alamat: " . $siswa["alamat"];
?>