<?php
require 'interface_hewanpeliharaan.php';
$anjing = new Anjing();
$kucing = new Kucing();
$anjing->bersuara();
echo "<br>";
$anjing->makan();
echo "<hr>";
$kucing->bersuara();
echo "<br>";
$kucing->makan();
?>