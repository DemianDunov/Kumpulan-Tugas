class Rectangle {
  #panjang;
  #lebar;
  constructor(p, l) {
    this.#panjang = p;
    this.#lebar = l;
  }
  getLuas() {
    return this.#panjang * this.#lebar;
  }
  getKeliling() {
    return 2 * (this.#panjang + this.#lebar);
  }
}
let rect = new Rectangle(10, 5);
console.log("Luas:", rect.getLuas());
console.log("Keliling:", rect.getKeliling());