from abc import ABC, abstractmethod

# Abstract Class
class BangunDatar(ABC):

    @abstractmethod
    def luas(self):
        pass

    @abstractmethod
    def keliling(self):
        pass


# Persegi
class Persegi(BangunDatar):

    sisi = 6

    def luas(self):
        return self.sisi * self.sisi

    def keliling(self):
        return 4 * self.sisi


# Persegi Panjang
class PersegiPanjang(BangunDatar):

    panjang = 10
    lebar = 5

    def luas(self):
        return self.panjang * self.lebar

    def keliling(self):
        return 2 * (self.panjang + self.lebar)


# Segitiga
class Segitiga(BangunDatar):

    alas = 8
    tinggi = 6
    sisi = 8

    def luas(self):
        return 0.5 * self.alas * self.tinggi

    def keliling(self):
        return 3 * self.sisi


# OUTPUT

persegi = Persegi()

print("=== Persegi ===")
print("Luas :", persegi.luas())
print("Keliling :", persegi.keliling())

print()

pp = PersegiPanjang()

print("=== Persegi Panjang ===")
print("Luas :", pp.luas())
print("Keliling :", pp.keliling())

print()

segitiga = Segitiga()

print("=== Segitiga ===")
print("Luas :", segitiga.luas())
print("Keliling :", segitiga.keliling())