class Sepeda {
  #warna;
  #kecepatan;
  setWarna(w) {
    this.#warna = w;
  }
  getWarna() {
    return this.#warna;
  }
  setKecepatan(k) {
    if (k >= 0) this.#kecepatan = k;
  }
  getKecepatan() {
    return this.#kecepatan;
  }
}
let sepeda = new Sepeda();
sepeda.setWarna("Biru");
sepeda.setKecepatan(30);
console.log("Sepeda:", sepeda.getWarna(), sepeda.getKecepatan());