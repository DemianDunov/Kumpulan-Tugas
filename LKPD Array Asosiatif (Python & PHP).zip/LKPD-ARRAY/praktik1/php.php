<?php
$siswa = [
    "nama" => "Demian",
    "umur" => 18,
    "jurusan" => "EKONOMI & BISNIS"
];

echo "Nama: " . $siswa["nama"] . "<br>";
echo "Umur: " . $siswa["umur"] . "<br>";
echo "Jurusan: " . $siswa["jurusan"];
?>