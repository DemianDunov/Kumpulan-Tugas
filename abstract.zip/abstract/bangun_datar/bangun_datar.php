<?php

abstract class BangunDatar {

    abstract public function luas();
    abstract public function keliling();
}


// Persegi
class Persegi extends BangunDatar {

    public $sisi = 6;

    public function luas() {
        return $this->sisi * $this->sisi;
    }

    public function keliling() {
        return 4 * $this->sisi;
    }
}


// Persegi Panjang
class PersegiPanjang extends BangunDatar {

    public $panjang = 10;
    public $lebar = 5;

    public function luas() {
        return $this->panjang * $this->lebar;
    }

    public function keliling() {
        return 2 * ($this->panjang + $this->lebar);
    }
}


// Segitiga
class Segitiga extends BangunDatar {

    public $alas = 8;
    public $tinggi = 6;
    public $sisi = 8;

    public function luas() {
        return 0.5 * $this->alas * $this->tinggi;
    }

    public function keliling() {
        return 3 * $this->sisi;
    }
}


// OUTPUT

$persegi = new Persegi();

echo "=== Persegi ===<br>";
echo "Luas : " . $persegi->luas() . "<br>";
echo "Keliling : " . $persegi->keliling() . "<br><br>";


$pp = new PersegiPanjang();

echo "=== Persegi Panjang ===<br>";
echo "Luas : " . $pp->luas() . "<br>";
echo "Keliling : " . $pp->keliling() . "<br><br>";


$segitiga = new Segitiga();

echo "=== Segitiga ===<br>";
echo "Luas : " . $segitiga->luas() . "<br>";
echo "Keliling : " . $segitiga->keliling();

?>