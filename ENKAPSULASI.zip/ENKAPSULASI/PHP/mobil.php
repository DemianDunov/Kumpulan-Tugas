<?php
class Mobil {
    private $warna;
    private $kecepatan;
    function setWarna($warna){ $this->warna = $warna; }
    function getWarna(){ return $this->warna; }
    function setKecepatan($k){ if($k >= 0) $this->kecepatan = $k; }
    function getKecepatan(){ return $this->kecepatan; }
}
?>