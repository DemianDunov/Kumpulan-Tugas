<?php

// 1. Buku & BukuTeks
class Buku {
    public $judul, $pengarang, $harga;

    function __construct($judul, $pengarang, $harga) {
        $this->judul = $judul;
        $this->pengarang = $pengarang;
        $this->harga = $harga;
    }

    function tampil_info() {
        echo "Buku: $this->judul - $this->pengarang - $this->harga<br>";
    }
}

class BukuTeks extends Buku {
    public $isbn;

    function __construct($judul, $pengarang, $harga, $isbn) {
        parent::__construct($judul, $pengarang, $harga);
        $this->isbn = $isbn;
    }

    function tampil_info() {
        echo "BukuTeks: $this->judul - $this->pengarang - $this->harga - ISBN: $this->isbn<br>";
    }
}

$b1 = new BukuTeks("Hitam Putih","EL Manuk",10000,"123");
$b1->tampil_info();


// 2. Sepeda & SepedaListrik
class Sepeda {
    public $merek, $warna, $harga;

    function __construct($merek, $warna, $harga) {
        $this->merek = $merek;
        $this->warna = $warna;
        $this->harga = $harga;
    }

    function berjalan() {
        echo "Sepeda Berjalan<br>";
    }
}

class SepedaListrik extends Sepeda {
    public $baterai;

    function __construct($merek, $warna, $harga, $baterai) {
        parent::__construct($merek, $warna, $harga);
        $this->baterai = $baterai;
    }

    function isi_ulang() {
        echo "Mengisi ulang baterai<br>";
    }
}

$s = new SepedaListrik("Selis","Hitam",5000000,100);
$s->berjalan();
$s->isi_ulang();


// 3. Mobil & MobilListrik
class Mobil {
    public $merek, $warna, $harga, $tahun;

    function __construct($merek, $warna, $harga, $tahun) {
        $this->merek = $merek;
        $this->warna = $warna;
        $this->harga = $harga;
        $this->tahun = $tahun;
    }

    function berjalan() {
        echo "Mobil berjalan<br>";
    }
}

class MobilListrik extends Mobil {
    public $baterai;

    function __construct($merek, $warna, $harga, $tahun, $baterai) {
        parent::__construct($merek, $warna, $harga, $tahun);
        $this->baterai = $baterai;
    }

    function isi_ulang() {
        echo "Mengisi ulang baterai<br>";
    }
}

$m = new MobilListrik("Tesla","Putih",1000000000,2024,100);
$m->berjalan();
$m->isi_ulang();


// 4. BangunDatar & PersegiPanjang
class BangunDatar {
    public $warna;

    function __construct($warna) {
        $this->warna = $warna;
    }

    function hitung_luas() {
        echo "Menghitung luas bangun datar<br>";
    }
}

class PersegiPanjang extends BangunDatar {
    public $p, $l;

    function __construct($warna, $p, $l) {
        parent::__construct($warna);
        $this->p = $p;
        $this->l = $l;
    }

    function hitung_luas() {
        echo "Luas: ".($this->p * $this->l)."<br>";
    }
}

$pp = new PersegiPanjang("Merah",10,5);
$pp->hitung_luas();


// 5. Kendaraan, Motor, Sepeda
class Kendaraan {
    public $merek, $tahun;

    function __construct($merek, $tahun) {
        $this->merek = $merek;
        $this->tahun = $tahun;
    }

    function berjalan() {
        echo "Kendaraan bergerak<br>";
    }
}

class Motor extends Kendaraan {
    public $bbm;

    function __construct($merek, $tahun, $bbm) {
        parent::__construct($merek, $tahun);
        $this->bbm = $bbm;
    }

    function nyalakan_mesin() {
        echo "Mesin mobil dinyalakan<br>";
    }
}

class Sepeda2 extends Kendaraan {
    public $jenis;

    function __construct($merek, $tahun, $jenis) {
        parent::__construct($merek, $tahun);
        $this->jenis = $jenis;
    }

    function gowes() {
        echo "Sepeda sedang digowes<br>";
    }
}

$motor = new Motor("Honda",2020,"Bensin");
$motor->berjalan();
$motor->nyalakan_mesin();

$sepeda2 = new Sepeda2("Polygon",2022,"Gunung");
$sepeda2->berjalan();
$sepeda2->gowes();


// 6. Hewan
class Hewan {
    function suara() {
        echo "Hewan bersuara<br>";
    }
}

class Kucing extends Hewan {
    function suara() {
        echo "Meow!<br>";
    }
}

class Anjing extends Hewan {
    function suara() {
        echo "Woof!<br>";
    }
}

class Kelinci extends Hewan {
    function suara() {
        echo "Squeak!<br>";
    }
}

(new Kucing())->suara();
(new Anjing())->suara();
(new Kelinci())->suara();


// 7. Lingkaran & Segitiga
class Lingkaran extends BangunDatar {
    public $r;

    function __construct($r) {
        $this->r = $r;
    }

    function hitung_luas() {
        echo "Luas Lingkaran: ".(pi() * $this->r * $this->r)."<br>";
    }
}

class Segitiga extends BangunDatar {
    public $a, $t;

    function __construct($a, $t) {
        $this->a = $a;
        $this->t = $t;
    }

    function hitung_luas() {
        echo "Luas Segitiga: ".(0.5 * $this->a * $this->t)."<br>";
    }
}

(new Lingkaran(7))->hitung_luas();
(new Segitiga(10,5))->hitung_luas();


// 8. Barang
class Barang {
    public $nama, $harga;

    function __construct($nama, $harga) {
        $this->nama = $nama;
        $this->harga = $harga;
    }

    function tampil_info() {
        echo "$this->nama - $this->harga<br>";
    }
}

class Elektronik extends Barang {
    public $garansi;

    function __construct($nama, $harga, $garansi) {
        parent::__construct($nama, $harga);
        $this->garansi = $garansi;
    }

    function tampil_info() {
        echo "$this->nama - $this->harga - Garansi: $this->garansi<br>";
    }
}

class Pakaian extends Barang {
    public $ukuran;

    function __construct($nama, $harga, $ukuran) {
        parent::__construct($nama, $harga);
        $this->ukuran = $ukuran;
    }

    function tampil_info() {
        echo "$this->nama - $this->harga - Ukuran: $this->ukuran<br>";
    }
}

class Makanan extends Barang {
    public $exp;

    function __construct($nama, $harga, $exp) {
        parent::__construct($nama, $harga);
        $this->exp = $exp;
    }

    function tampil_info() {
        echo "$this->nama - $this->harga - Exp: $this->exp<br>";
    }
}

(new Elektronik("HP",3000000,"1 tahun"))->tampil_info();
(new Pakaian("Kaos",100000,"L"))->tampil_info();
(new Makanan("Roti",20000,"2026"))->tampil_info();

?>