<?php
class Mahasiswa {
    private $nama;
    private $nim;
    function setNama($nama){ $this->nama = $nama; }
    function getNama(){ return $this->nama; }
    function setNim($nim){ $this->nim = $nim; }
    function getNim(){ return $this->nim; }
}
?>