<?php
interface Login {
    public function masuk($username, $password);
    public function logout();
    public function gantiPassword($username, $passwordLama, $passwordBaru);
}
class Admin implements Login {
    public function masuk($username, $password) {
        echo "Admin $username berhasil login";
    }
    public function logout() {
        echo "Admin berhasil logout";
    }
    public function gantiPassword($username, $passwordLama, $passwordBaru) {
        echo "Admin $username berhasil mengganti password";
    }
}
class Guru implements Login {
    public function masuk($username, $password) {
        echo "Guru $username berhasil login";
    }
    public function logout() {
        echo "Guru berhasil logout";
    }
    public function gantiPassword($username, $passwordLama, $passwordBaru) {
        echo "Guru $username berhasil mengganti password";
    }
}
class Siswa implements Login {
    public function masuk($username, $password) {
        echo "Siswa $username berhasil login";
    }
    public function logout() {
        echo "Siswa berhasil logout";
    }
    public function gantiPassword($username, $passwordLama, $passwordBaru) {
        echo "Siswa $username berhasil mengganti password";
    }
}

?>
