<?php
interface HewanPeliharaan {
    public function bersuara();
    public function makan();
}
class Anjing implements HewanPeliharaan {
    public function bersuara() {
        echo "nggok gok!!";
    }
    public function makan() {
        echo "Anjing makan tulang";
    }
}
class Kucing implements HewanPeliharaan {
    public function bersuara() {
        echo "Miaww~~";
    }
    public function makan() {
        echo "Kucing makan ikan";
    }
}
?>  
