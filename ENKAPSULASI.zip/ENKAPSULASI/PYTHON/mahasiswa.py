class Mahasiswa:
    def __init__(self, nama, nim):
        self.__nama = nama
        self.__nim = nim

    def set_nama(self, nama):
        self.__nama = nama

    def get_nama(self):
        return self.__nama

    def set_nim(self, nim):
        self.__nim = nim

    def get_nim(self):
        return self.__nim
    
mhs = Mahasiswa("Demian", "12345")
print("Mahasiswa:", mhs.get_nama(), mhs.get_nim())