class Mobil {
  #warna;
  #kecepatan;
  setWarna(w) {
    this.#warna = w;
  }
  getWarna() {
    return this.#warna;
  }
  setKecepatan(k) {
    if (k >= 0) this.#kecepatan = k;
  }

  getKecepatan() {
    return this.#kecepatan;
  }
}
let mobil = new Mobil();
mobil.setWarna("Merah");
mobil.setKecepatan(120);
console.log("Mobil:", mobil.getWarna(), mobil.getKecepatan());
