<?php
$produk = [
    "produk1" => ["nama" => "Buku Tulis", "harga" => 5000, "stok" => 10],
    "produk2" => ["nama" => "Pulpen", "harga" => 250, "stok" => 20],
    "produk3" => ["nama" => "Penghapus", "harga" => 100, "stok" => 15]
];

// tampil semua data
foreach ($produk as $key => $value) {
    echo $key . " : ";
    print_r($value);
    echo "<br>";
}

// hitung total nilai stok
$total = 0;
foreach ($produk as $item) {
    $total += $item["harga"] * $item["stok"];
}

echo "Total nilai stok: " . $total;
?>