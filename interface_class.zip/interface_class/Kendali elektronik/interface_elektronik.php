<?php
interface Kendali {
    public function hidupkan();
    public function matikan();
}
class Lampu implements Kendali {
    public function hidupkan() {
        return "Lampu menyala";
    }
    public function matikan() {
        return "Lampu mati";
    }
}class TV implements Kendali {
    public function hidupkan() {
        return "TV menyala";
    }
    public function matikan() {
        return "TV mati";
    }
}
// $lampu = new Lampu();
// echo $lampu->hidupkan() . "<br>";
// echo $lampu->matikan() . "<br>";
// $tv = new TV();
// echo $tv->hidupkan() . "<br>";
// echo $tv->matikan() . "<br>";
?>
