class Kendaraan {
    constructor(merk) {
        this.merk = merk;
    }

    tampilkanMerk() {
        return "Merk: " + this.merk;
    }
}

class Mobil extends Kendaraan {
    infoMobil() {
        return "Ini adalah mobil " + this.merk;
    }

    kecepatanMaks() {
        return "Kecepatan maks: 200 km/jam";
    }
}

let mobil1 = new Mobil("Mitsubishi");
console.log(mobil1.tampilkanMerk());
console.log(mobil1.infoMobil());
console.log(mobil1.kecepatanMaks());