// Abstract Class
class BangunDatar {

    constructor() {
        if (this.constructor === BangunDatar) {
            throw new Error("Class abstrak tidak bisa dibuat!");
        }
    }

    luas() {
        throw new Error("Method harus diisi!");
    }

    keliling() {
        throw new Error("Method harus diisi!");
    }
}


// Persegi
class Persegi extends BangunDatar {

    constructor() {
        super();
        this.sisi = 6;
    }

    luas() {
        return this.sisi * this.sisi;
    }

    keliling() {
        return 4 * this.sisi;
    }
}


// Persegi Panjang
class PersegiPanjang extends BangunDatar {

    constructor() {
        super();
        this.panjang = 10;
        this.lebar = 5;
    }

    luas() {
        return this.panjang * this.lebar;
    }

    keliling() {
        return 2 * (this.panjang + this.lebar);
    }
}


// Segitiga
class Segitiga extends BangunDatar {

    constructor() {
        super();
        this.alas = 8;
        this.tinggi = 6;
        this.sisi = 8;
    }

    luas() {
        return 0.5 * this.alas * this.tinggi;
    }

    keliling() {
        return 3 * this.sisi;
    }
}


// OUTPUT

const persegi = new Persegi();

console.log("=== Persegi ===");
console.log("Luas :", persegi.luas());
console.log("Keliling :", persegi.keliling());

console.log("");

const pp = new PersegiPanjang();

console.log("=== Persegi Panjang ===");
console.log("Luas :", pp.luas());
console.log("Keliling :", pp.keliling());

console.log("");

const segitiga = new Segitiga();

console.log("=== Segitiga ===");
console.log("Luas :", segitiga.luas());
console.log("Keliling :", segitiga.keliling());