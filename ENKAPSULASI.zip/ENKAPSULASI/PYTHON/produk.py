class Produk:
    def __init__(self, nama, harga):
        self.__nama = nama
        self.__harga = harga

    def set_nama(self, nama):
        self.__nama = nama

    def get_nama(self):
        return self.__nama

    def set_harga(self, harga):
        if harga >= 0:
            self.__harga = harga

    def get_harga(self):
        return self.__harga

produk = Produk("Laptop", 5000000)
print("Produk:", produk.get_nama(), produk.get_harga())

produk.set_harga(6000000)
print("Produk update:", produk.get_nama(), produk.get_harga())