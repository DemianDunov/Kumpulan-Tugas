class Mahasiswa {
  #nama;
  #nim;
  setNama(n) {
    this.#nama = n;
  }
  getNama() {
    return this.#nama;
  }

  setNim(nim) {
    this.#nim = nim;
  }
  getNim() {
    return this.#nim;
  }
}

let mhs = new Mahasiswa ();
mhs.setNama("Demian");
mhs.setNim("12345");

console.log("Nama:", mhs.getNama());
console.log("NIM:", mhs.getNim());
