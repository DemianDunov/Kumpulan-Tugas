class Rectangle:
    def __init__(self, panjang, lebar):
        self.__panjang = panjang
        self.__lebar = lebar

    def get_luas(self):
        return self.__panjang * self.__lebar

    def get_keliling(self):
        return 2 * (self.__panjang + self.__lebar)
rect = Rectangle(10, 5)
print("Luas:", rect.get_luas())
print("Keliling:", rect.get_keliling())
